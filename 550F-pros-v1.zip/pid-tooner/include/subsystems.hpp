#pragma once

#include "EZ-Template/api.hpp"
#include "api.h"

extern Drive chassis;

// Your motors, sensors, etc. should go here.  Below are examples

inline pros::Motor intakeMain(-8);
inline pros::Motor intakeTop(1);
inline ez::Piston tongue('B');
inline ez::Piston wing('A');

// inline pros::Motor intake(1);
// inline pros::adi::DigitalIn limit_switch('A');