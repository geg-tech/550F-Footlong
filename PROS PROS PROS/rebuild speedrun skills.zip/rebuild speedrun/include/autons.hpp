#pragma once

void default_constants();

void drive_example();
void turn_example();
void drive_and_turn();
void wait_until_change_speed();
void skills_auto();
void left_wing_rush();
void right_wing_rush();
void left_blocks();
void right_blocks();
void parking_test();