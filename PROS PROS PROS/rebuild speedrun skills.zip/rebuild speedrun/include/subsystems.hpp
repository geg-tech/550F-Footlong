#pragma once

#include "EZ-Template/api.hpp"
#include "api.h"

extern Drive chassis;

// Your motors, sensors, etc. should go here.  Below are examples
inline pros::Motor intakeMain(-9);
inline pros::Motor intakeTop(8);
inline ez::Piston tongue('G');
inline ez::Piston wing('H');
inline ez::Piston midgoal('F');
// inline pros::Motor intake(1);
// inline pros::adi::DigitalIn limit_switch('A');